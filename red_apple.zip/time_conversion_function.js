//function which will convert 12 hours format to 24 hours format and also divide time intervels
module.exports = { timeslotter:function (start,end,num_of_pateints) 

{const moment = require('moment');
    let timeSlots = []
  const hhmm_format_start = moment(start, ["h:mm A"]).format("HH:mm");
  const hhmm_format_end =  moment(end, ["h:mm A"]).format("HH:mm");

  const start_time_array = hhmm_format_start.split(':');
  const end_time_array = hhmm_format_end.split(':');

  const hour_start = start_time_array[0];
  const minute_start = start_time_array[1];

  const hour_end = end_time_array[0];
  const minute_end = end_time_array[1];

  const converted_start_time =  moment().set({hour:hour_start,minute:minute_start});
  const converted_end_time = moment().set({hour:hour_end,minute:minute_end});
  
  const intervel  = Math.round((Math.abs(converted_end_time-converted_start_time)/1000)/60)/num_of_pateints;
  

  while(converted_start_time <= converted_end_time){
      timeSlots.push(new moment(converted_start_time).format('HH:mm'));
      converted_start_time.add(intervel, 'minutes');
  }

  return timeSlots;
}
}


