const appRouter = (app) => {
    const { check, validationResult } = require("express-validator/check"); // importing express validator
    const database = require('../config/database');
    const time_slotter = require('../time_conversion_function.js'); //importing time slotting function



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////Endpoint for adding timeslot in database (Answer - 1)//////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 

    app.post("/doc_avb", [
        check("doctor_id", "it's mandatory").not().isEmpty(), check("start_time", "it's mandatory").not().isEmpty(),
        check("end_time", "it's mandatory").not().isEmpty(), check("no_of_patients", "it's mandatory").not().isEmpty()], 
        async (req, res) => {
            const errors = validationResult(req);
            if (!errors.isEmpty()) 
            {
                return res.status(400).json({ errors: errors.array() }); //returning an array after validation
            }

            try {
                const doctor_id = req.body.doctor_id;
                const start_time = req.body.start_time;
                const end_time = req.body.end_time;
                const num_of_pateints = req.body.no_of_patients;
                const slotted_array = await time_slotter.timeslotter(start_time, end_time, num_of_pateints);  // slotted time in array from time_conversion_function.js file

                {   //////////////////inserting into doctor availablity////////////////////////

                    let sql_doc_avb = "INSERT INTO doctor_availabilities VALUES ('','" + doctor_id + "','" + start_time + "','" + end_time + "','" + num_of_pateints + "')";
                    await database.query(sql_doc_avb, function (err, result) {
                        if (err) console.log(err);
                    });

                    for (i = 0; i < slotted_array.length - 1; i++) {

                        ///////////////////inserting into doctor_time_slot//////////////////////////

                        let sql_doc_slots = "INSERT INTO doctor_time_slots VALUES ('','" + doctor_id + "','" + doctor_id + "','" + slotted_array[i] + "','" + slotted_array[i + 1] + "')";
                        await database.query(sql_doc_slots, function (err, result) {
                            if (err) console.log(err);
                        });
                    }

                    res.send({ message: "sucessfully added" });
                }
            } catch (err) 
                {
                    console.log(err.message);
                    res.status(500).send("something went worng");
                }
        });



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////Endpoint for checking availablity (Answer - 2)//////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    app.post("/slot_avbl", [
        check("appointment_date", "it's mandatory").not().isEmpty(), check("patient_id", "it's mandatory").not().isEmpty(),
        check("doctor_time_slot_id", "it's mandatory").not().isEmpty(), check("number_of_patient", "it's mandatory").not().isEmpty()], async (req, res) => {
            const errors = validationResult(req);
            if (!errors.isEmpty()) 
                {
                    return res.status(400).json({ errors: errors.array() }); //sending an error array after failed validation
                }

            const appoinment_date = req.body.appointment_date;
            const patient_id = req.body.patient_id;
            const doctor_time_slot_id = req.body.doctor_time_slot_id;
            const number_of_patient = req.body.number_of_patient;

            try {
                /////////checking the doctor's id in patient booking list//////////////////////////////////////////////////////

                 await database.query("SELECT * FROM patient_booking_slots WHERE doctor_time_slot_id = '" + doctor_time_slot_id + "'", function (err, result) {
                    if (err) console.log(err);

                    if (result.length == 0) 
                    {
                        let available_slots_current = [];
                        let available_slots_next = [];
                        database.query("SELECT * FROM doctor_time_slots WHERE doctor_id = '" + doctor_time_slot_id + "'", (err, result) => {
                            if (err) console.log(err);
                                if (number_of_patient > result.length)  //number of patients should not exceeds doctor's maximum slots
                                {
                                    return res.send({ message: "number of patient is more than doctor's availablity" });
                                }
                            for (i = 0; i < number_of_patient; i++)  //fetching slots for number_of_patients
                                {
                                    slots = {
                                        status: "available for you",
                                        time: result[i].slot_start_time + " - " + result[i].slot_end_time
                                    }
                                    available_slots_current.push(slots);
                                }

                            for (i = number_of_patient; i < result.length; i++)  //fetching slots for next patients
                                {
                                    slots_next = {
                                        status: "available for next patient",
                                        time: result[i].slot_start_time + " - " + result[i].slot_end_time,
                                    }
                                    available_slots_next.push(slots_next);
                                }

                            return res.send({ current: available_slots_current, next: available_slots_next });
                        });
                    }
                    else {
                        res.send({ message: "sorry!Doctor is not available" })
                    }
                });
            }
            catch (err) {
                console.log(err.message);
                res.status(500).send("something went worng");
            }

        });
}

module.exports = appRouter;